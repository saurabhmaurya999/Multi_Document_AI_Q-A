import os
from pathlib import Path
from flask import Flask, render_template, request, jsonify
from werkzeug.utils import secure_filename

from langchain_community.document_loaders import PyPDFLoader
from langchain_text_splitters import RecursiveCharacterTextSplitter
from langchain_huggingface import HuggingFaceEmbeddings, HuggingFaceEndpoint, ChatHuggingFace
from langchain_community.vectorstores import FAISS
from langchain_core.prompts import ChatPromptTemplate

BASE_DIR = Path(__file__).resolve().parent
UPLOAD_DIR = BASE_DIR / "uploads"
UPLOAD_DIR.mkdir(exist_ok=True)

ALLOWED_EXTENSIONS = {"pdf"}
app = Flask(__name__)
app.config["MAX_CONTENT_LENGTH"] = 50 * 1024 * 1024  # 50 MB total request

retriever = None
model = None
document_names = []

prompt = ChatPromptTemplate.from_template("""
You are a helpful document assistant.

Answer the question using ONLY the provided context.

If the answer is not available in the context, say:
"I could not find this information in the uploaded documents."

Context:
{context}

Question:
{question}

Answer:
""")

def allowed_file(filename):
    return "." in filename and filename.rsplit(".", 1)[1].lower() in ALLOWED_EXTENSIONS

def build_pipeline(pdf_paths):
    global retriever, model, document_names

    all_documents = []
    document_names = [Path(p).name for p in pdf_paths]

    for path in pdf_paths:
        loader = PyPDFLoader(str(path))
        all_documents.extend(loader.load())

    splitter = RecursiveCharacterTextSplitter(
        chunk_size=500,
        chunk_overlap=100
    )
    chunks = splitter.split_documents(all_documents)

    embedding_model = HuggingFaceEmbeddings(
        model_name="sentence-transformers/all-MiniLM-L6-v2"
    )

    vectorstore = FAISS.from_documents(chunks, embedding_model)

    # Same MMR retrieval idea as the notebook, with the LangChain argument name.
    retriever = vectorstore.as_retriever(
        search_type="mmr",
        search_kwargs={
            "k": 4,
            "fetch_k": 10,
            "lambda_mult": 0.7
        }
    )

    hf_token = os.getenv("HF_TOKEN")
    if not hf_token:
        raise RuntimeError("HF_TOKEN environment variable is not set.")

    llm = HuggingFaceEndpoint(
        repo_id="Qwen/Qwen3-4B-Instruct-2507",
        task="text-generation",
        huggingfacehub_api_token=hf_token
    )
    model = ChatHuggingFace(llm=llm)

def ask_question(question):
    if retriever is None or model is None:
        raise RuntimeError("Please upload at least one PDF first.")

    retrieved_docs = retriever.invoke(question)
    context = "\n\n".join(doc.page_content for doc in retrieved_docs)

    messages = prompt.invoke({
        "context": context,
        "question": question
    })
    response = model.invoke(messages)

    sources = []
    seen = set()
    for doc in retrieved_docs:
        source = doc.metadata.get("source", "Unknown")
        page = doc.metadata.get("page", 0)
        item = f"{Path(source).name} - Page {page + 1}"
        if item not in seen:
            sources.append(item)
            seen.add(item)

    return response.content, sources

@app.route("/")
def index():
    return render_template(
        "index.html",
        documents=document_names,
        ready=retriever is not None
    )

@app.post("/upload")
def upload():
    files = request.files.getlist("files")
    if not files or all(not f.filename for f in files):
        return jsonify({"ok": False, "error": "Please select one or more PDF files."}), 400

    # Clear previous uploaded PDFs for this simple single-user app.
    for old in UPLOAD_DIR.glob("*.pdf"):
        old.unlink(missing_ok=True)

    saved = []
    for file in files:
        if not file.filename or not allowed_file(file.filename):
            return jsonify({"ok": False, "error": "Only PDF files are supported."}), 400

        filename = secure_filename(file.filename)
        path = UPLOAD_DIR / filename
        file.save(path)
        saved.append(path)

    try:
        build_pipeline(saved)
        total_pages = 0
        for path in saved:
            total_pages += len(PyPDFLoader(str(path)).load())

        return jsonify({
            "ok": True,
            "documents": [p.name for p in saved],
            "pages": total_pages
        })
    except Exception as e:
        return jsonify({"ok": False, "error": str(e)}), 500

@app.post("/ask")
def ask():
    data = request.get_json(silent=True) or {}
    question = (data.get("question") or "").strip()

    if not question:
        return jsonify({"ok": False, "error": "Please enter a question."}), 400

    try:
        answer, sources = ask_question(question)
        return jsonify({"ok": True, "answer": answer, "sources": sources})
    except Exception as e:
        return jsonify({"ok": False, "error": str(e)}), 500

if __name__ == "__main__":
    app.run(debug=True)
